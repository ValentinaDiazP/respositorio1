import numpy as np
import pandas as pd
import json
import os
import csv
import folium
from geopy.geocoders import Nominatim
from geopy.distance import geodesic

class Modelo(object):
    def __init__(self, file='usuarios.json'):
        self.file= file
        self.__usuarios= self.cargar()

    def cargar(self): 
        if not os.path.exists(self.file):
            self.inicializar()
        try:
            with open(self.file, 'r') as archivo:
                usuarios = json.load(archivo)
        except (FileNotFoundError, json.JSONDecodeError):
            usuarios = {}
        return usuarios

    def inicializar(self):
        with open(self.file, 'w') as archivo:
            json.dump({}, archivo)

    def guardar(self):
        with open(self.file, 'w') as archivo:
            json.dump(self.__usuarios, archivo, indent=4)

    def verificarUsuario(self, u, p):
        try:
            return self.__usuarios[p] == u
        except KeyError:
            return False

    def agregarUsuario(self, u, p):
        self.__usuarios[p] = u
        self.guardar()

class SEIRModel:
    def __init__(self, N=500, E0=10, I0=0, R0=2, beta=0.3, sigma=0.1, gamma=0.1):
        self.N= N
        self.S= N - E0 - I0 - R0
        self.E= E0
        self.I= I0
        self.R= R0
        self.beta= beta
        self.sigma= sigma
        self.gamma= gamma

        np.random.seed(42)
        self.coords= np.random.rand(N, 2) * 10
        self.states= np.array(['S']*self.S+['E'] * self.E + ['I'] * self.I + ['R'] * self.R)

    def step(self):
        dS= -self.beta * self.S * self.I / self.N
        dE= self.beta * self.S * self.I / self.N - self.sigma * self.E
        dI= self.sigma * self.E - self.gamma * self.I
        dR= self.gamma * self.I

        self.S += dS
        self.E += dE
        self.I += dI
        self.R += dR

        nuevoEstado= self.states.copy()
        
        for i in range(self.N):
            if self.states[i]== 'S':
                if np.random.rand() < self.beta * (self.I / self.N):
                    nuevoEstado[i] = 'E'
            elif self.states[i]== 'E':
                if np.random.rand() < self.sigma:
                    nuevoEstado[i] = 'I'
            elif self.states[i]== 'I':
                if np.random.rand() < self.gamma:
                    nuevoEstado[i]= 'R'
        
        self.states= nuevoEstado
        self.S= sum(self.states == 'S')
        self.E= sum(self.states == 'E')
        self.I= sum(self.states == 'I')
        self.R= sum(self.states == 'R')

    def getCoordenadas(self):
        return self.coords, self.states
    
class SEIRModelVacunado(SEIRModel):
    def __init__(self, N, E0, I0, R0, beta, sigma, gamma, tasaVacunacion):
        super().__init__(N, E0, I0, R0, beta, sigma, gamma)
        self.tasaVacunacion= tasaVacunacion

    def step(self):
        dS= -self.beta * self.S *(1 - self.tasaVacunacion) * self.I / self.N
        dE= self.beta * self.S *(1 - self.tasaVacunacion) * self.I / self.N - self.sigma * self.E
        dI= self.sigma * self.E - self.gamma * self.I
        dR= self.gamma * self.I

        self.S += dS
        self.E += dE
        self.I += dI
        self.R += dR

        nuevoEstado = self.states.copy()
        for i in range(self.N):
            if self.states[i] == 'S':
                if np.random.rand() < self.beta * (1 - self.tasaVacunacion) * (self.I / self.N):
                    nuevoEstado[i] = 'E'
            elif self.states[i] == 'E':
                if np.random.rand() < self.sigma:
                    nuevoEstado[i] = 'I'
            elif self.states[i] == 'I':
                if np.random.rand() < self.gamma:
                    nuevoEstado[i] = 'R'

        self.states = nuevoEstado
        self.S = sum(self.states == 'S')
        self.E = sum(self.states == 'E')
        self.I = sum(self.states == 'I')
        self.R = sum(self.states == 'R')
      
class EpidemiaModelo:
    def __init__(self):
        self.poblacionI= 0
        self.infectadosI= 0
        self.tasaInfeccion = 0
        self.tasaRecuperacion = 0
        self.dias = 0
        self.geolocator= Nominatim(user_agent="tu_aplicacion_nombre_version")


    def calcularEpidemia(self, poblacionI, infectadosI, tasaInfeccion, tasaRecuperacion, dias):
        self.poblacionI = poblacionI
        self.infectadosI = infectadosI
        self.tasaInfeccion = tasaInfeccion
        self.tasaRecuperacion = tasaRecuperacion
        self.dias = dias

        susceptibles = [self.poblacionI- self.infectadosI]
        infectados = [self.infectadosI]
        recuperados = [0]

        for i in range(self.dias):
            nuevosInfectados = int(susceptibles[i] * self.tasaInfeccion * infectados[i] / self.poblacionI)
            nuevosRecuperados = int(infectados[i] * self.tasaRecuperacion)

            susceptibles.append(susceptibles[i] - nuevosInfectados)
            infectados.append(infectados[i] + nuevosInfectados - nuevosRecuperados)
            recuperados.append(recuperados[i] + nuevosRecuperados)

        return pd.DataFrame({
            'Susceptibles': susceptibles,
            'Infectados': infectados,
            'Recuperados': recuperados
        })
    
    def buscarInfectados(self, lat, lon, radio=5): #BUSCA INFECTADOS CERCANOS A 5KM #latitud y longitud que ingresa el usuario
        infectados= []
        with open('infectados1.csv', mode='r') as file:
            csv_reader = csv.DictReader(file)
            for row in csv_reader:
                lat= float(row['latitud'])
                lon= float(row['longitud'])#latitud y longitud de los infectados
                distancia= geodesic((lat, lon), (lat, lon)).kilometers
                if distancia<= radio:
                    infectados.append((row['direccion'], lat, lon))
        return infectados

    def mapaFolium(self, lat, lon, infectados): #latitud y longitud del usuario
        m= folium.Map(location=[lat, lon], zoom_start=10)
        folium.Marker([lat, lon], popup='Tu ubicación', icon=folium.Icon(color='blue')).add_to(m)
        for infectado in infectados:
            direccion, lat, lon = infectado
            folium.Marker([lat, lon], popup=direccion, icon=folium.Icon(color='red')).add_to(m)
        mapa= os.path.abspath('mapa.html')
        m.save(mapa)
        return mapa

    def geolocalizar(self, direccion):
        location = self.geolocator.geocode(direccion)
        if location:
            return location.latitude, location.longitude
        else:
            raise ValueError("Ubicación no encontrada") #control con IF

    def guardarInfectado(self, texto, lat, lon): #Manejo de bd=archivo csv
        db= 'infectados1.csv'
        if not os.path.isfile(db):
            with open(db, 'w', newline='') as file:
                writer= csv.writer(file)
                writer.writerow(['id', 'direccion', 'latitud', 'longitud'])
        with open(db, 'r') as file:
            dbReader = csv.DictReader(file)
            ids = [int(row['id']) for row in dbReader]
            nuevoID = max(ids) + 1 if ids else 1
        with open(db, 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([nuevoID, texto, lat, lon])

    def salida(self):
        pass 