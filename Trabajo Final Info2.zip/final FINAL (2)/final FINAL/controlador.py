from PyQt5.QtWidgets import QApplication
import sys
from vista import Ventana 
from modelo import SEIRModel, SEIRModelVacunado, Modelo, EpidemiaModelo

class Controlador: 
    def __init__(self, modelo): 
        self.__mi_modelo = modelo

    def validarUsuario(self, u, p):
        return self.__mi_modelo.verificarUsuario(u, p)

    def agregarUsuario(self, u, p):
        return self.__mi_modelo.agregarUsuario(u, p)

class Coordinador:
    def __init__(self, vista, SEIRvac, SEIRsinVac):
        self.__vista= vista
        self.SEIRvac= SEIRvac
        self.SEIRsinVac = SEIRsinVac
        self.__ventanaEmergente = None

    def asignarVentanaEmergente(self, ventanaEmergente):
        self.__ventanaEmergente= ventanaEmergente

    def actualizarVacunados(self, tiempo): #actualiza el tiempo de la grafica de los vacunados
        if not self.SEIRvac:
            return
        for _ in range(tiempo):
            self.SEIRvac.step()
        
        coords,states =self.SEIRvac.getCoordenadas()
        
        if self.__ventanaEmergente:
            self.__ventanaEmergente.graficaVac.actualizarDatos(coords, states)

    def actualizarnoVacunados(self, tiempo):
        if not self.SEIRsinVac:
            return

        for _ in range(tiempo):
            self.SEIRsinVac.step()
        
        coords, states= self.SEIRsinVac.getCoordenadas()
        
        if self.__ventanaEmergente:
            self.__ventanaEmergente.graficanoVac.actualizarDatos(coords, states)

    
class ControladorEpidemia:
    def __init__(self, vistaEmergente, modeloEpidemia):
        self.__mi_vista = vistaEmergente
        self.__mi_modelo = modeloEpidemia

    def calcularEpidemia(self, poblacionI, infectadosIniciales, tasaInfeccion, tasaRecuperacion, dias):
        return self.__mi_modelo.calcularEpidemia(poblacionI, infectadosIniciales, tasaInfeccion, tasaRecuperacion, dias)
    
    def buscarInfectados(self, lat, lon, radio_km=5):
        return self.__mi_modelo.buscarInfectados(lat, lon, radio_km)

    def mostrarMapa(self, lat, lon, infectados):
        return self.__mi_modelo.mapaFolium(lat, lon, infectados)

    def geolocalizar(self, direccion):
        return self.__mi_modelo.geolocalizar(direccion)

    def guardarInfectado(self, texto, lat, lon):
        self.__mi_modelo.guardarInfectado(texto, lat, lon)

def main():
    app = QApplication(sys.argv)

    modelo= Modelo()
    SEIRVac= SEIRModelVacunado(N=500, E0=10, I0=0, R0=2, beta=0.3, sigma=0.1, gamma=0.1, tasaVacunacion=0.08)
    SEIRsinVac= SEIRModel(N=500, E0=10, I0=0, R0=2, beta=0.3, sigma=0.1, gamma=0.1)
    modeloEpidemia= EpidemiaModelo()
    
    #controladores
    controlador = Controlador(modelo)
    controladorEpidemia = ControladorEpidemia(None, modeloEpidemia)

    #crear ventana principal y controladores    
    ventanaPrincipal = Ventana()
    ventanaPrincipal.asignarControlador(Coordinador(ventanaPrincipal, SEIRVac, SEIRsinVac), controlador)
    ventanaPrincipal.asignarControladorEpidemia(controladorEpidemia)
    
    ventanaPrincipal.show()

    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
