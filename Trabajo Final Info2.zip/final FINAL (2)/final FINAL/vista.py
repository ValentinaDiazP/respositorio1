from PyQt5.QtWidgets import QMainWindow, QApplication, QVBoxLayout, QDialog, QMessageBox, QStackedWidget, QPushButton
from PyQt5.QtGui import QRegExpValidator
from PyQt5.QtCore import QRegExp
from PyQt5.uic import loadUi
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtCore import QUrl 


class Ventana(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi(r"VentanaLoguin.ui", self)
        self.setup()
        self.ventanaEmergente = None
        self.__controladorEpidemia = None 

    def setup(self):
        self.boton.clicked.connect(self.accionIngresar)
        self.boton_salir.clicked.connect(self.salirAplicacion)
        self.registrar.clicked.connect(self.abrirVentana)

    def abrirVentana(self):
        ventanaEmergente = registrar(self)
        ventanaEmergente.exec_()

    def asignarControlador(self, coordinador, controladorAuten):
        self.__controlador= coordinador
        self.__controladorAuten= controladorAuten

    def asignarControladorEpidemia(self, controladorEpidemia):
        self.__controladorEpidemia= controladorEpidemia

    def accionIngresar(self):
        usuario= self.usuario.text()
        contrasena= self.contrasena.text()
        resultado= self.__controladorAuten.validarUsuario(usuario, contrasena)
        
        if resultado:
            QMessageBox.information(self, "Resultado", "Usuario Valido")
            self.hide()
            if not self.ventanaEmergente:
                self.ventanaEmergente = VentanaEmergente()
                self.ventanaEmergente.asignarControlador(self.__controlador)
                self.ventanaEmergente.asignarControladorEpidemia(self.__controladorEpidemia)  # Se asigna el controlador de epidemia
                self.__controlador.asignarVentanaEmergente(self.ventanaEmergente)
            self.ventanaEmergente.show()
        else:
            QMessageBox.critical(self, "Resultado", "Usuario no Valido")
    
    def recibirInfo(self, usuario, password):
        resultado= self.__controladorAuten.validarUsuario(usuario, password)
        msg= QMessageBox(self)
        msg.setWindowTitle("Resultado")

        if resultado:
            msg.setText("El usuario ya estaba registrado")
        else:
            self.__controladorAuten.agregarUsuario(usuario, password)
            msg.setText("Usuario registrado con éxito")
        msg.show()

    def salirAplicacion(self):
        respuesta= QMessageBox.question(self, 'Salir', '¿Estás seguro de que quieres salir?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if respuesta== QMessageBox.Yes:
            QApplication.quit()

class registrar(QDialog):
    def __init__(self, ppl=None):
        super().__init__(ppl)
        loadUi(r"registro.ui", self)
        self.setWindowTitle("Ventana emergente")
        self.setup()
        self.parent= ppl

    def setup(self):
        self.Registrarse.accepted.connect(self.registro)
        self.Registrarse.rejected.connect(lambda: self.close())

    def registro(self):
        self.campo_usuario.setValidator(QRegExpValidator(QRegExp(r'^[\w\.-]+$')))
        usuario= self.campo_usuario.text()
        password= self.campo_password.text()

        if self.campo_usuario.hasAcceptableInput():
            self.parent.recibirInfo(usuario, password)
            print("Usuario valido")
            self.close()
        else:
            print("Usuario inválido")

class VentanaEmergente(QDialog):
    def __init__(self, ppal=None):
        super(VentanaEmergente, self).__init__(ppal)
        loadUi(r'VentanaEmergente.ui', self)
        self.__controladorEpidemia= None
        self.__controladorAuten= None
        self.__mi_vista_emergente= ppal
        self.__SEIRVac= None
        self.__SEIRsinVac= None

        self.graficaVac= None
        self.graficanoVac= None
    
        self.__coordinador= None
        self.valorSliderVac= 0  
        self.valorSlidernoVac= 0 

        self.setup()

    def setup(self):
        self.stackedWidget= self.findChild(QStackedWidget, "stackedWidget")
        self.grafica= CanvasGrafica()
        self.graficaVac= CanvasGrafica()
        self.graficanoVac= CanvasGrafica()
        self.boton_calculos= self.findChild(QPushButton, "calculos")
        self.boton_geo= self.findChild(QPushButton, "geo")
        self.boton_simulador= self.findChild(QPushButton, "simulador")
        self.calculos.clicked.connect(self.mostrarCalculos)
        self.geo.clicked.connect(self.mostrarGeolocalizador)
        self.simulador.clicked.connect(self.mostrarEpidemia)
        self.salir1.clicked.connect(self.salida)
        self.pushButton.clicked.connect(self.mostrarMapa)
        self.boton_calcular_epidemia.clicked.connect(self.calcularEpidemia)
        self.verticalLayout_vacuna.addWidget(self.graficaVac)
        self.verticalLayout_novacuna.addWidget(self.graficanoVac)
        self.time_slider_vac.valueChanged.connect(self.cambioSliderVac)
        self.time_slider_no_vac.valueChanged.connect(self.cambioSlidernoVac)

    def mostrarCalculos(self):
        self.stackedWidget.setCurrentIndex(1)

        if self.__SEIRVac and self.__SEIRsinVac:
            coords_vac, estados_vac = self.__SEIRVac.getCoordenadas()
            coords_no_vac, estados_no_vac = self.__SEIRsinVac.getCoordenadas()
            self.graficaVac.actualizarDatos(coords_vac, estados_vac)
            self.graficanoVac.actualizarDatos(coords_no_vac, estados_no_vac)
            num_dias = len(coords_vac) #dias totales

            #rango slider
            self.time_slider_vac.setMinimum(0)
            self.time_slider_vac.setMaximum(num_dias - 1)
            self.time_slider_no_vac.setMinimum(0)
            self.time_slider_no_vac.setMaximum(num_dias - 1)

        self.time_slider_vac.setValue(self.valorSliderVac)
        self.time_slider_no_vac.setValue(self.valorSlidernoVac)

    def cambioSliderVac(self, value):
        self.valorSliderVac = value
        self.__controlador.actualizarVacunados(value)

    def cambioSlidernoVac(self, value):
        self.valorSlidernoVac = value  
        self.__controlador.actualizarnoVacunados(value)

    def mostrarGeolocalizador(self):
        self.stackedWidget.setCurrentIndex(2)

    def mostrarEpidemia(self):
        self.stackedWidget.setCurrentIndex(3)
    
    def asignarControlador(self, c):
        self.__controlador = c

    def asignarCoordinador(self, coordinador):
        self.__coordinador = coordinador

    def asignarControladorEpidemia(self, controladorEpidemia):
        self.__controladorEpidemia = controladorEpidemia

    def mostrarMapa(self):
        direccion = self.lineEdit.text()
        try:
            latUsuario, lonUsuario= self.__controladorEpidemia.geolocalizar(direccion)
            infectados= self.__controladorEpidemia.buscarInfectados(latUsuario, lonUsuario)
            mapaHtml= self.__controladorEpidemia.mostrarMapa(latUsuario, lonUsuario, infectados)
            self.mostrarmapaHtml(mapaHtml)
        except ValueError as e:
            self.textEdit.setText(str(e))

        respuesta= QMessageBox.question(self, 'Confirmación', '¿Está infectado?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if respuesta== QMessageBox.Yes:
            texto= self.lineEdit.text()
            self.__controladorEpidemia.guardarInfectado(texto, latUsuario, lonUsuario)

    def mostrarmapaHtml(self, mapaHtml):
        ventanaMapa= QDialog(self)
        ventanaMapa.setWindowTitle("Mapa de Infectados")
        layout= QVBoxLayout(ventanaMapa)
        webView= QWebEngineView()
        layout.addWidget(webView)
        webView.setUrl(QUrl.fromLocalFile(mapaHtml))
        ventanaMapa.resize(800, 600)
        ventanaMapa.exec_()

    def calcularEpidemia(self):
        poblacion= self.input_poblacion.text()
        if poblacion:
            poblacionI =int(poblacion)
            infectadosI =int(self.input_infectados.text())
            tasaInfeccion =float(self.input_tasa_infeccion.text())
            tasaRecuperacion= float(self.input_tasa_recuperacion.text())
            dias= int(self.input_dias.text())
            if not hasattr(self, 'grafica2'):
                self.grafica2 = Canvas(self)
                self.verticalLayout.addWidget(self.grafica2)

            resultados = self.__controladorEpidemia.calcularEpidemia(poblacionI, infectadosI, tasaInfeccion, tasaRecuperacion, dias)

            self.grafica2.plot_results(resultados)

    def salida(self):
        respuesta = QMessageBox.question(self, 'Salir', '¿Estás seguro de que quieres salir?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if respuesta== QMessageBox.Yes:
            self.close()
            for widget in QApplication.topLevelWidgets():
                if isinstance(widget, Ventana):
                    widget.showNormal()
                    widget.activateWindow()
                    return
            ventana= Ventana()
            ventana.show()
   
class Canvas(FigureCanvas):
    def __init__(self, parent=None):
        self.fig, self.ax = plt.subplots(facecolor='gray')
        super().__init__(self.fig)
        self.ax.grid()
        self.ax.margins(x=0)
        
    def plot_results(self, resultados):
        self.ax.clear()
        self.ax.set_title("Resultados de la simulación de epidemia")
        self.ax.plot(resultados['Susceptibles'], label='Susceptibles')
        self.ax.plot(resultados['Infectados'], label='Infectados')
        self.ax.plot(resultados['Recuperados'], label='Recuperados')
        self.ax.legend()
        self.draw()
        plt.close()

    def convertirMatplotlib(self, series):
        x_values = [point.x() for point in series.pointsVector()]
        y_values = [point.y() for point in series.pointsVector()]
        return x_values, y_values
        
class CanvasGrafica(FigureCanvas):
    def __init__(self, parent=None):
        self.fig, self.ax = plt.subplots(facecolor='gray')
        super().__init__(self.fig)

        self.ax.margins(x=0)
        self.coords = None
        self.states = None
        self.plotScatter()

    def actualizarDatos(self, coords, states):
        self.coords = coords
        self.states = states
        self.plotScatter()

    def plotScatter(self):
        if self.coords is not None and self.states is not None:
            self.ax.clear()
            colors = {'S': 'blue', 'E': 'orange', 'I': 'red', 'R': 'green'}
            for state in colors:
                mask= self.states ==state
                self.ax.scatter(self.coords[mask, 0], self.coords[mask, 1], color=colors[state], label=state, alpha=0.6)           
            self.ax.set_title("Modelo SEIR - Propagación de la enfermedad")
            self.ax.set_xlim(0, 10) 
            self.ax.set_ylim(0, 10)
            self.ax.legend()
            self.draw()
